pip install -r requirements.txt 
python prepare_glue.py