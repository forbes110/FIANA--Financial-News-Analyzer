train on https://analyticsindiamag.com/10-popular-datasets-for-sentiment-analysis/
models:
    IDEA-CCNL/Erlangshen-MegatronBert-1.3B-Sentiment