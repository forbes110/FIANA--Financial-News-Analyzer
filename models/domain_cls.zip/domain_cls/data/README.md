cleaned data(json) to be used
